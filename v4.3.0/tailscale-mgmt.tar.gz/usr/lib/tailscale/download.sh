#!/bin/sh
# Download, extraction, and symlink management functions
# Sourced by tailscale-manager entry script.
#
# Required variables (set by entry script before sourcing):
#   DOWNLOAD_BASE, SMALL_DOWNLOAD_BASE, SMALL_SUPPORTED_ARCHS,
#   SMALL_RELEASES_API
#
# Required functions (from entry script):
#   log_info(), log_error(), log_warn(), download_repo_file()

create_tailscale_temp_dir() {
    local prefix="${1:-tailscale}"
    local base="${TMPDIR:-/tmp}"
    local tmp_dir=""

    tmp_dir=$(mktemp -d "${base%/}/${prefix}.XXXXXX" 2>/dev/null) \
        || tmp_dir=$(mktemp -d -t "${prefix}.XXXXXX" 2>/dev/null) \
        || {
            log_error "Failed to create private temporary directory"
            return 1
        }

    chmod 700 "$tmp_dir" 2>/dev/null || true
    printf '%s\n' "$tmp_dir"
}

checksum_emergency_override_enabled() {
    case "${TAILSCALE_ALLOW_UNVERIFIED_DOWNLOAD:-}" in
        1|true|TRUE|yes|YES) return 0 ;;
        *) return 1 ;;
    esac
}

is_safe_tar_path() {
    local path="$1"

    case "$path" in
        ""|/*|../*|*/../*|*/..|..)
            return 1
            ;;
        *)
            return 0
            ;;
    esac
}

validate_tar_member_paths() {
    local tarball="$1"
    local list_file="$2"
    local verbose_file="${list_file}.verbose"
    local member line target

    if ! tar tzf "$tarball" > "$list_file" 2>/dev/null; then
        log_error "Failed to list archive contents"
        return 1
    fi

    while IFS= read -r member; do
        if ! is_safe_tar_path "$member"; then
            log_error "Archive contains unsafe path: ${member}"
            return 1
        fi
    done < "$list_file"

    if ! tar tvzf "$tarball" > "$verbose_file" 2>/dev/null; then
        log_error "Failed to list archive details"
        return 1
    fi

    while IFS= read -r line; do
        case "$line" in
            l*" -> "*)
                target=${line##* -> }
                if ! is_safe_tar_path "$target"; then
                    log_error "Archive contains unsafe link target: ${target}"
                    return 1
                fi
                ;;
            l*)
                log_error "Failed to parse archive symlink target"
                return 1
                ;;
            h*" link to "*)
                target=${line##* link to }
                if ! is_safe_tar_path "$target"; then
                    log_error "Archive contains unsafe link target: ${target}"
                    return 1
                fi
                ;;
            h*)
                log_error "Failed to parse archive hardlink target"
                return 1
                ;;
        esac
    done < "$verbose_file"

    return 0
}

# Compute SHA-256 hash of a file
# Uses sha256sum (coreutils/busybox) or openssl as fallback
compute_sha256() {
    local file="$1"

    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$file" | awk '{print $1}'
    elif command -v openssl >/dev/null 2>&1; then
        openssl dgst -sha256 "$file" | awk '{print $NF}'
    else
        return 1
    fi
}

# Verify file checksum against expected SHA-256 hash
# Returns 0 on match, 1 on mismatch or missing tools
verify_checksum() {
    local file="$1"
    local expected="$2"

    local actual
    actual=$(compute_sha256 "$file") || {
        if checksum_emergency_override_enabled; then
            log_warn "Emergency checksum override enabled: sha256 tool is unavailable"
            return 0
        fi
        log_error "sha256 verification requires sha256sum or openssl"
        return 1
    }

    if [ "$actual" != "$expected" ]; then
        log_error "Checksum mismatch!"
        log_error "  Expected: $expected"
        log_error "  Got:      $actual"
        return 1
    fi

    log_info "Checksum verified: $expected"
    return 0
}

# Fetch expected SHA-256 for official Tailscale tarball
# pkgs.tailscale.com supports appending .sha256 to any download URL
get_official_checksum() {
    local url="$1"
    local checksum

    checksum=$(wget -qO- "${url}.sha256" 2>/dev/null) || return 1

    # Validate format: must be exactly 64 hex characters
    case "$checksum" in
        [0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f])
            echo "$checksum"
            ;;
        *)
            return 1
            ;;
    esac
}

# Fetch expected SHA-256 for small binary from GitHub API release asset digest
# GitHub API returns digest as "sha256:<hex>" in each asset object
get_small_checksum() {
    local version="$1"
    local filename="$2"
    local api_data
    local digest
    local filename_pattern

    api_data=$(wget -qO- "${SMALL_RELEASES_API}/tags/v${version}" 2>/dev/null) || return 1

    filename_pattern=$(printf '%s\n' "$filename" | sed 's/[][\\/.*^$]/\\&/g')

    # GitHub's REST API may return compact single-line JSON depending on the
    # client / network path. First strip all newlines so both compact and
    # pretty-printed input become a single line, then re-introduce a newline
    # only at asset object boundaries (},{) so each asset ends up on its own
    # line. Without this, the greedy .* in the digest substitution captures
    # the *last* sha256 in the entire response (typically the asset listed
    # last alphabetically) instead of the one for the requested file.
    #
    # awk is used for the boundary split because POSIX/BSD sed does not
    # portably interpret \n in the replacement as a newline; awk's gsub does.
    # Braces are wrapped in character classes ([{] / [}]) because BusyBox awk
    # otherwise reads `*{` as the start of a {n,m} interval expression and
    # rejects the regex with "Invalid contents of {}".
    digest=$(printf '%s' "$api_data" \
        | tr -d '\n' \
        | awk '{gsub(/[}],[[:space:]]*[{]/, "}\n{"); print}' \
        | sed -n "/\"name\"[[:space:]]*:[[:space:]]*\"${filename_pattern}\"/{
            s/.*\"sha256:\([0-9a-f]*\)\".*/\1/p
            q
        }")

    if [ -z "$digest" ]; then
        return 1
    fi

    echo "$digest"
}

# Check if architecture is supported by small binaries
is_arch_supported_by_small() {
    local arch="$1"
    case " $SMALL_SUPPORTED_ARCHS " in
        *" $arch "*) return 0 ;;
        *) return 1 ;;
    esac
}

# Detect wget capabilities and return appropriate progress option
get_wget_progress_option() {
    if wget --help 2>&1 | grep -q -- '--progress'; then
        echo "--progress=bar:force"
    else
        echo "-q"
    fi
}

# Download dispatcher: routes to official or small based on DOWNLOAD_SOURCE
download_tailscale() {
    local version="$1"
    local arch="$2"
    local target_dir="$3"

    if [ "$DOWNLOAD_SOURCE" = "small" ]; then
        download_tailscale_small "$version" "$arch" "$target_dir"
    else
        download_tailscale_official "$version" "$arch" "$target_dir"
    fi
}

# Stage new version: download to a temporary directory without touching the live install.
# Returns 0 on success, leaving staged files in $stage_dir for the caller to install.
stage_tailscale() {
    local version="$1"
    local arch="$2"
    local stage_dir="$3"

    mkdir -p "$stage_dir"
    download_tailscale "$version" "$arch" "$stage_dir"
}

# Verify a staged binary is runnable on the current device.
# Executes tailscaled --version from the stage directory to catch architecture
# mismatches, corrupted UPX compression, or missing dynamic libraries early,
# before the live install is touched.
verify_staged_binary() {
    local stage_dir="$1"
    local bin

    if [ -f "${stage_dir}/tailscale.combined" ]; then
        bin="${stage_dir}/tailscale.combined"
    elif [ -f "${stage_dir}/tailscaled" ]; then
        bin="${stage_dir}/tailscaled"
    else
        log_error "No binary found in staging directory"
        return 1
    fi

    chmod +x "$bin"
    if ! "$bin" --version >/dev/null 2>&1; then
        log_error "Staged binary failed verification (--version check)"
        return 1
    fi

    log_info "Staged binary verified successfully"
    return 0
}

# Install staged files into the live binary directory.
# Handles both official (separate tailscale + tailscaled) and small (combined) layouts.
install_staged() {
    local stage_dir="$1"
    local target_dir="$2"
    local suffix=".$$"
    local managed_files="tailscale tailscaled tailscale.combined version source"
    local name cleanup_name deploy_failed=0

    mkdir -p "$target_dir"

    if [ -f "${stage_dir}/tailscale.combined" ]; then
        mv "${stage_dir}/tailscale.combined" "${target_dir}/.tailscale.combined.new${suffix}" || return 1
        chmod +x "${target_dir}/.tailscale.combined.new${suffix}" || {
            rm -f "${target_dir}/.tailscale.combined.new${suffix}"
            return 1
        }
    else
        mv "${stage_dir}/tailscaled" "${target_dir}/.tailscaled.new${suffix}" || return 1
        mv "${stage_dir}/tailscale" "${target_dir}/.tailscale.new${suffix}" || {
            rm -f "${target_dir}/.tailscaled.new${suffix}"
            return 1
        }
        chmod +x "${target_dir}/.tailscaled.new${suffix}" "${target_dir}/.tailscale.new${suffix}" || {
            rm -f "${target_dir}/.tailscaled.new${suffix}" "${target_dir}/.tailscale.new${suffix}"
            return 1
        }
    fi

    [ ! -f "${stage_dir}/version" ] || mv "${stage_dir}/version" "${target_dir}/.version.new${suffix}" || {
        for name in $managed_files; do rm -f "${target_dir}/.${name}.new${suffix}"; done
        return 1
    }
    [ ! -f "${stage_dir}/source" ] || mv "${stage_dir}/source" "${target_dir}/.source.new${suffix}" || {
        for name in $managed_files; do rm -f "${target_dir}/.${name}.new${suffix}"; done
        return 1
    }

    for name in $managed_files; do
        rm -f "${target_dir}/.${name}.bak${suffix}"
        if [ -e "${target_dir}/${name}" ] || [ -L "${target_dir}/${name}" ]; then
            mv -f "${target_dir}/${name}" "${target_dir}/.${name}.bak${suffix}" || {
                log_error "Failed to back up ${target_dir}/${name}"
                for cleanup_name in $managed_files; do
                    rm -f "${target_dir}/.${cleanup_name}.new${suffix}"
                    if [ -e "${target_dir}/.${cleanup_name}.bak${suffix}" ] || [ -L "${target_dir}/.${cleanup_name}.bak${suffix}" ]; then
                        mv -f "${target_dir}/.${cleanup_name}.bak${suffix}" "${target_dir}/${cleanup_name}" 2>/dev/null || true
                    fi
                done
                return 1
            }
        fi
    done

    if [ -f "${target_dir}/.tailscale.combined.new${suffix}" ]; then
        mv "${target_dir}/.tailscale.combined.new${suffix}" "${target_dir}/tailscale.combined" || deploy_failed=1
        (
            cd "$target_dir" || exit 1
            ln -sf "tailscale.combined" "tailscale" || exit 1
            ln -sf "tailscale.combined" "tailscaled" || exit 1
        ) || deploy_failed=1
    else
        mv "${target_dir}/.tailscaled.new${suffix}" "${target_dir}/tailscaled" || deploy_failed=1
        mv "${target_dir}/.tailscale.new${suffix}" "${target_dir}/tailscale" || deploy_failed=1
    fi

    [ ! -f "${target_dir}/.version.new${suffix}" ] || mv "${target_dir}/.version.new${suffix}" "${target_dir}/version" || deploy_failed=1
    [ ! -f "${target_dir}/.source.new${suffix}" ] || mv "${target_dir}/.source.new${suffix}" "${target_dir}/source" || deploy_failed=1

    if [ "$deploy_failed" = "1" ]; then
        log_error "Failed to install staged files, restoring previous binaries"
        for name in $managed_files; do
            rm -f "${target_dir}/${name}" "${target_dir}/.${name}.new${suffix}"
            if [ -e "${target_dir}/.${name}.bak${suffix}" ] || [ -L "${target_dir}/.${name}.bak${suffix}" ]; then
                mv -f "${target_dir}/.${name}.bak${suffix}" "${target_dir}/${name}" 2>/dev/null || true
            fi
        done
        return 1
    fi

    for name in $managed_files; do
        rm -f "${target_dir}/.${name}.bak${suffix}" "${target_dir}/.${name}.new${suffix}"
    done
}

# Download official Tailscale binaries from pkgs.tailscale.com
download_tailscale_official() {
    local version="$1"
    local arch="$2"
    local target_dir="$3"

    local official_arch="$arch"
    case "$arch" in
        armv5|armv6) official_arch="arm" ;;
    esac

    local filename="tailscale_${version}_${official_arch}.tgz"
    local url="${DOWNLOAD_BASE}/${filename}"
    local tmp_dir
    local tarball

    tmp_dir=$(create_tailscale_temp_dir "tailscale-download") || return 1
    tarball="${tmp_dir}/${filename}"

    log_info "Downloading Tailscale v${version} for ${arch} (official)..."
    log_info "URL: $url"

    local expected_checksum
    expected_checksum=$(get_official_checksum "$url") || {
        if checksum_emergency_override_enabled; then
            log_warn "Emergency checksum override enabled: could not fetch ${url}.sha256"
            expected_checksum=""
        else
            log_error "Could not fetch checksum from ${url}.sha256"
            rm -rf "$tmp_dir"
            return 1
        fi
    }

    local wget_progress
    wget_progress=$(get_wget_progress_option)
    if ! wget "$wget_progress" -O "$tarball" "$url" 2>&1; then
        log_error "Download failed"
        rm -rf "$tmp_dir"
        return 1
    fi

    if [ -n "$expected_checksum" ] && ! verify_checksum "$tarball" "$expected_checksum"; then
        rm -rf "$tmp_dir"
        return 1
    fi

    log_info "Extracting..."
    if ! validate_tar_member_paths "$tarball" "${tmp_dir}/archive-members.list"; then
        rm -rf "$tmp_dir"
        return 1
    fi

    if ! tar xzf "$tarball" -C "$tmp_dir" 2>&1; then
        log_error "Extraction failed"
        rm -rf "$tmp_dir"
        return 1
    fi

    local extracted_dir="${tmp_dir}/tailscale_${version}_${official_arch}"
    if [ ! -f "${extracted_dir}/tailscaled" ] || [ ! -f "${extracted_dir}/tailscale" ]; then
        log_error "Required binaries not found in archive"
        rm -rf "$tmp_dir"
        return 1
    fi

    log_info "Installing to ${target_dir}..."
    mkdir -p "$target_dir"
    mv "${extracted_dir}/tailscaled" "${target_dir}/tailscaled"
    mv "${extracted_dir}/tailscale" "${target_dir}/tailscale"
    chmod +x "${target_dir}/tailscaled" "${target_dir}/tailscale"

    echo "$version" > "${target_dir}/version"
    echo "official" > "${target_dir}/source"

    rm -rf "$tmp_dir"

    log_info "Successfully installed Tailscale v${version}"
    return 0
}

# Download small/compressed Tailscale binaries from GitHub releases
download_tailscale_small() {
    local version="$1"
    local arch="$2"
    local target_dir="$3"

    local filename="tailscale-small_${version}_${arch}.tgz"
    local url="${SMALL_DOWNLOAD_BASE}/v${version}/${filename}"
    local tmp_dir
    local tarball

    tmp_dir=$(create_tailscale_temp_dir "tailscale-download") || return 1
    tarball="${tmp_dir}/${filename}"

    log_info "Downloading Tailscale v${version} for ${arch} (small/compressed)..."
    log_info "URL: $url"

    local expected_checksum
    expected_checksum=$(get_small_checksum "$version" "$filename") || {
        if checksum_emergency_override_enabled; then
            log_warn "Emergency checksum override enabled: could not fetch checksum from GitHub API"
            expected_checksum=""
        else
            log_error "Could not fetch checksum from GitHub API"
            rm -rf "$tmp_dir"
            return 1
        fi
    }

    local wget_progress
    wget_progress=$(get_wget_progress_option)
    if ! wget "$wget_progress" -O "$tarball" "$url" 2>&1; then
        log_error "Download failed"
        rm -rf "$tmp_dir"
        return 1
    fi

    if [ -n "$expected_checksum" ] && ! verify_checksum "$tarball" "$expected_checksum"; then
        rm -rf "$tmp_dir"
        return 1
    fi

    log_info "Extracting..."
    if ! validate_tar_member_paths "$tarball" "${tmp_dir}/archive-members.list"; then
        rm -rf "$tmp_dir"
        return 1
    fi

    if ! tar xzf "$tarball" -C "$tmp_dir" 2>&1; then
        log_error "Extraction failed"
        rm -rf "$tmp_dir"
        return 1
    fi

    local extracted_dir="${tmp_dir}/tailscale-small_${version}_${arch}"

    if [ ! -f "${extracted_dir}/tailscale.combined" ]; then
        log_error "Combined binary not found in archive"
        rm -rf "$tmp_dir"
        return 1
    fi

    log_info "Installing to ${target_dir}..."
    mkdir -p "$target_dir"

    mv "${extracted_dir}/tailscale.combined" "${target_dir}/tailscale.combined"
    chmod +x "${target_dir}/tailscale.combined"

    (
        cd "$target_dir" || exit 1
        ln -sf "tailscale.combined" "tailscale"
        ln -sf "tailscale.combined" "tailscaled"
    ) || {
        log_error "Failed to enter ${target_dir} to create symlinks"
        rm -rf "$tmp_dir"
        return 1
    }

    echo "$version" > "${target_dir}/version"
    echo "small" > "${target_dir}/source"

    rm -rf "$tmp_dir"

    log_info "Successfully installed Tailscale v${version} (small)"
    return 0
}

# Create /usr/bin symlinks pointing to the binary directory
_user_bin_path() {
    printf '%s/%s' "${USER_BIN_DIR:-/usr/bin}" "$1"
}

_is_managed_bin_link() {
    local link="$1"
    local target="$2"
    local current_target=""

    [ -L "$link" ] || return 1
    current_target=$(readlink "$link" 2>/dev/null) || return 1
    [ "$current_target" = "$target" ]
}

_ensure_bin_link_slot() {
    local link="$1"
    shift
    local target

    if [ ! -e "$link" ] && [ ! -L "$link" ]; then
        return 0
    fi

    for target in "$@"; do
        [ -n "$target" ] || continue
        if _is_managed_bin_link "$link" "$target"; then
            return 0
        fi
    done

    log_error "Refusing to overwrite non-managed command: ${link}"
    return 1
}

create_symlinks() {
    local bin_dir="$1"
    local tailscale_link tailscaled_link

    tailscale_link=$(_user_bin_path tailscale)
    tailscaled_link=$(_user_bin_path tailscaled)

    _ensure_bin_link_slot "$tailscale_link" \
        "${bin_dir}/tailscale" \
        "${PERSISTENT_DIR:-/opt/tailscale}/tailscale" \
        "${RAM_DIR:-/tmp/tailscale}/tailscale" || return 1
    _ensure_bin_link_slot "$tailscaled_link" \
        "${bin_dir}/tailscaled" \
        "${PERSISTENT_DIR:-/opt/tailscale}/tailscaled" \
        "${RAM_DIR:-/tmp/tailscale}/tailscaled" || return 1

    rm -f "$tailscale_link" "$tailscaled_link"
    ln -sf "${bin_dir}/tailscale" "$tailscale_link"
    ln -sf "${bin_dir}/tailscaled" "$tailscaled_link"

    log_info "Created symlinks in ${USER_BIN_DIR:-/usr/bin}/"
}

# Remove /usr/bin symlinks
remove_symlinks() {
    local tailscale_link tailscaled_link dir removed=0

    tailscale_link=$(_user_bin_path tailscale)
    tailscaled_link=$(_user_bin_path tailscaled)

    if [ "$#" -eq 0 ]; then
        set -- "${PERSISTENT_DIR:-/opt/tailscale}" "${RAM_DIR:-/tmp/tailscale}"
    fi

    for dir in "$@"; do
        [ -n "$dir" ] || continue
        if _is_managed_bin_link "$tailscale_link" "${dir}/tailscale"; then
            rm -f "$tailscale_link"
            removed=1
        fi
        if _is_managed_bin_link "$tailscaled_link" "${dir}/tailscaled"; then
            rm -f "$tailscaled_link"
            removed=1
        fi
    done

    if [ "$removed" = "1" ]; then
        log_info "Removed managed symlinks from ${USER_BIN_DIR:-/usr/bin}/"
    else
        log_info "No managed symlinks found in ${USER_BIN_DIR:-/usr/bin}/"
    fi
}
